import utils

def test_load_data():
    X, y = utils.load_data('classificationA.train')

if __name__ == "__main__":
    test_load_data()
